/*
 * $Id: EchoServlet.java,v 1.5 2003/06/22 12:32:15 fukuda Exp $
 */
package org.mobicents.servlet.sip.example;

import java.util.*;
import java.io.IOException;

import javax.servlet.sip.SipServlet;
import javax.servlet.sip.SipServletRequest;
import javax.servlet.sip.SipServletResponse;
import javax.servlet.ServletException;
import javax.servlet.sip.URI;

import org.apache.catalina.connector.Request;

import com.sun.mail.iap.Response;

import javax.servlet.sip.Proxy;
import javax.servlet.sip.SipFactory;

/**
 */
public class Redirect extends SipServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static private Map<String, String> Binding;
	static private SipFactory factory;
	static private String assinante;

	public Redirect() {
		super();
		Binding = new HashMap<String, String>();
	}

	public void init() {
		factory = (SipFactory) getServletContext().getAttribute(SIP_FACTORY);
	}

	/**
	 * Acts as a registrar and location service for REGISTER messages
	 * 
	 * @param request
	 *            The SIP message received by the AS
	 */
	protected void doRegister(SipServletRequest request) throws ServletException, IOException {
		String aor = getSIPuri(request.getHeader("To"));
		String contact = getSIPuriPort(request.getHeader("Contact"));

		SipServletResponse response;

		if (aor.contains("acme.pt")) {
			// Registrar dentro do dominio
			Binding.put(aor, contact);
			response = request.createResponse(200);
		} else {
			// Não registrar se está fora do dominio
			response = request.createResponse(401);
		}
		response.send();

		// Some logs to show the content of the Registrar database.
		log("REGISTER:***");
		Iterator<Map.Entry<String, String>> it = Binding.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> pairs = (Map.Entry<String, String>) it.next();
			System.out.println(pairs.getKey() + " = " + pairs.getValue());
		}
		log("REGISTER:***");
	}

	/**
	 * Sends SIP replies to INVITE messages - 300 if registred - 404 if not
	 * registred
	 * 
	 * @param request
	 *            The SIP message received by the AS
	 */
	protected void doInvite(SipServletRequest request)
			throws ServletException, IOException {
		
		SipServletResponse response;

		String aor = getSIPuri(request.getHeader("To")); // Get the To AoR
		String contact = getSIPuriPort(request.getHeader("Contact"));

		// String contact = getSIPuriPort(request.getHeader("Contact"));
		List<URI> listAor = new LinkedList<URI>();
		
		if(aor.contains("acme.pt")) {
			// Para utilizadores subscritos
			if (!Binding.containsKey(aor)) { // To AoR not in the database, reply 404
				response = request.createResponse(404);
			} else {
				//Se o AoR estiver na Base de Dados
				// SipServletResponse response = request.createResponse(300);
				// Get the To AoR contact from the database and add it to the
				// response
				// response.setHeader("Contact",Binding.get(aor));

				listAor.add((URI) factory.createURI(Binding.get(aor)));

				Proxy proxy = request.getProxy();
				// Útil sprint posteriores
				proxy.setRecordRoute(true);
				proxy.setSupervised(true);
				proxy.proxyTo(listAor);

				// O proxyTo executa o seguinte comando:
				// response.send();
			}
		} else {
			// Resposta de erro 401 para users que não do dominio acme.pt
			response = request.createResponse(401);
			response.send();
		}
		
		// Some logs to show the content of the Invite database.
				log("INVITE:***");
				Iterator<Map.Entry<String, String>> it = Binding.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<String, String> pairs = (Map.Entry<String, String>) it.next();
					System.out.println(pairs.getKey() + " = " + pairs.getValue());
				}
				log("INVITE:***");
	}

	protected void doErrorResponse(SipServletResponse response) throws ServletException, IOException {
		String aor = getSIPuri(response.getHeader("To"));
		String contact = getSIPuriPort(response.getHeader("Contact"));

		// Se a resposta for um "Busy Here - 486"
		if (response.getStatus() == 486) {
			// Tem de ser enviada uma mensagem ao assinante com o AoR
			// Através do teclado, muda o comportamento
			// Tecla 1 - Manter a chamada em que está envolvido. O chamador
			// recebe a resposta 486 e termina a chamada
			// Tecla 2 - O chamada e o novo chamador ficam em conversa e o
			// antigo participante é ligado a um atendedor automático

			// Enviar o AoR do novo chamador para o assinante do serviço

			assinante = aor;
			SipServletRequest message = factory.createRequest(response.getApplicationSession(), "MESSAGE", assinante,
					Binding.get(aor));
			message.setContent(response.getContent(), response.getContentType());
			message.send();

			log("486:***");
			System.out.print("Estou ocupado");
			log("486:***");

		} else {
			// Se não receber o 486, procede normalmente

			List<URI> listAor = new LinkedList<URI>();
			listAor.add((URI) factory.createURI(Binding.get(aor)));
			Proxy proxy = response.getProxy();
			// Útil sprint posteriores
			proxy.setRecordRoute(true);
			proxy.setSupervised(true);
			proxy.proxyTo(listAor);

		}
	}

	protected void doMessage(SipServletRequest request, SipServletResponse response)
			throws IOException, ServletException {
		String aor = getSIPuri(response.getHeader("To"));
		String contact = getSIPuriPort(response.getHeader("Contact"));
		String[] message = request.getContent().toString().split(" ");

		// Meramente exemplo, não sei se funciona
		if (message[0].contains("1")) {
			// Chamador recebe resposta Original
		}
		if (message[0].contains("2")) {
			// Estabelecer um diálogo entre o novo utilizador e o subscritor de
			// serviço
		}
	}

	/**
	 * Auxiliary function for extracting SPI URIs
	 * 
	 * @param uri
	 *            A URI with optional extra attributes
	 * @return SIP URI
	 */
	protected String getSIPuri(String uri) {
		String f = uri.substring(uri.indexOf("<") + 1, uri.indexOf(">"));
		int indexCollon = f.indexOf(":", f.indexOf("@"));
		if (indexCollon != -1) {
			f = f.substring(0, indexCollon);
		}
		return f;
	}

	/**
	 * Auxiliary function for extracting SPI URIs
	 * 
	 * @param uri
	 *            A URI with optional extra attributes
	 * @return SIP URI and port
	 */
	protected String getSIPuriPort(String uri) {
		String f = uri.substring(uri.indexOf("<") + 1, uri.indexOf(">"));
		return f;
	}
}
